#ifndef NEOKERN_TIMER_H
#define NEOKERN_TIMER_H

#include "types.h"

void timer_init(void);
int  timer_is_ready(void);
u64  timer_ticks(void);

#endif