#include <stdint.h>

static inline uint64_t read_rflags(void) {
    uint64_t flags;
    __asm__ volatile (
        "pushfq\n"
        "pop %0"
        : "=r"(flags)
    );
    return flags;
}

int interrupts_are_disabled(void) {
    uint64_t rflags = read_rflags();
    return !(rflags & (1 << 9));
}

void interrupts_enforce_off(void) {
    __asm__ volatile ("cli");
}