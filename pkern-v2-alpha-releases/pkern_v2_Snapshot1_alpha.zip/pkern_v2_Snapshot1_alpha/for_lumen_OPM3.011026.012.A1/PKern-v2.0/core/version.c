#include "version.h"

/*
 * Static kernel version descriptor
 */
static struct kernel_version version = {
    .major = PALISADE_KERNEL_MAJOR,
    .minor = PALISADE_KERNEL_MINOR,
    .patch = PALISADE_KERNEL_PATCH,
    .build = PALISADE_BUILD_ID
};

const struct kernel_version *kernel_version_get(void) {
    return &version;
}

int kernel_version_match(u32 maj, u32 min) {
    if (version.major != maj)
        return 0;
    if (version.minor != min)
        return 0;
    return 1;
}