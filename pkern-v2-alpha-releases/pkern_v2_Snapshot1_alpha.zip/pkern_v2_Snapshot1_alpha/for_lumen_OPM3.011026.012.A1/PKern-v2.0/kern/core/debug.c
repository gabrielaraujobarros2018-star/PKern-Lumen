#include <stdint.h>

void debug_banner(void)
{
    /* stub or serial print later */
}

void debug_checkpoint(const char *msg)
{
    (void)msg;
    /* stub */
}