/* ============================================================
 * NeoKern C Entry Point
 * Called directly from _start (assembly)
 * ============================================================ */

/* Prevent removal and enforce boot contract */
__attribute__((used))
__attribute__((noreturn))
void kernel_start(void)
{
    /* kmain MUST NOT return */
    __attribute__((noreturn))
    extern void kmain(void);

    kmain();

    /* Absolute safety net — should never be reached */
    for (;;)
        __asm__ volatile ("hlt");
}