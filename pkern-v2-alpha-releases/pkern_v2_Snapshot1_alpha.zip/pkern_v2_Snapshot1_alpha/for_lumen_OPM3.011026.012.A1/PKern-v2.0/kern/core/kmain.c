#include <stdint.h>

extern void kernel_main(void);

void kmain(void)
{
    kernel_main();

    for (;;)
        __asm__ volatile ("hlt");
}