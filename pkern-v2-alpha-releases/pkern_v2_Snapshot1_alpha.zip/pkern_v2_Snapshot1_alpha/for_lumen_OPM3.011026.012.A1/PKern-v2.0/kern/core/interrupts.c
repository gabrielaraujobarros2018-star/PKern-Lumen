#include "kernel.h"

void interrupts_enforce_off(void) {
#if defined(NEOKERN_ARCH_X86_64)
    __asm__ volatile ("cli" ::: "memory");
#elif defined(NEOKERN_ARCH_AARCH64)
    __asm__ volatile ("msr DAIFSet, #2" ::: "memory");
#endif
}

int interrupts_are_disabled(void) {
#if defined(NEOKERN_ARCH_X86_64)
    u64 flags;
    __asm__ volatile ("pushfq; pop %0" : "=r"(flags));
    return !(flags & (1ULL << 9));
#elif defined(NEOKERN_ARCH_AARCH64)
    u64 daif;
    __asm__ volatile ("mrs %0, DAIF" : "=r"(daif));
    return (daif & (1 << 7)) != 0;
#endif
}