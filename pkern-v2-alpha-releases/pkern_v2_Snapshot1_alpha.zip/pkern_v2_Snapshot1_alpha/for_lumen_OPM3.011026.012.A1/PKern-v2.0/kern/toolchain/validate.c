#include <stdint.h>

int kernel_toolchain_validate(void) {
#if defined(__x86_64__) || defined(__aarch64__)
    return 1;
#else
    return 0;
#endif
}

int kernel_cross_compile_ok(void) {
#if defined(__x86_64__) && defined(__aarch64__)
    return 0;
#else
    return 1;
#endif
}