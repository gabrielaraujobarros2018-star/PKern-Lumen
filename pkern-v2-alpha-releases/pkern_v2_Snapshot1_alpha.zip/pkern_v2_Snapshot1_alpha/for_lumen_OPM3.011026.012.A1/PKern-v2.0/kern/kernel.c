#include <stdint.h>

extern int mmu_validate_state(void);
extern int interrupts_are_disabled(void);
extern void interrupts_enforce_off(void);
extern void panic(uint64_t code);

void kernel_main(void)
{
    interrupts_enforce_off();

    if (!interrupts_are_disabled()) {
        panic(3);
    }

    if (mmu_validate_state() != 0) {
        panic(4);
    }

    volatile uint16_t *vga = (uint16_t *)0xB8000;
    vga[0] = (0x2F << 8) | 'O';
    vga[1] = (0x2F << 8) | 'K';

    for (;;) {
        __asm__ volatile ("hlt");
    }
}