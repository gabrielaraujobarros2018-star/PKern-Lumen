#include <stdint.h>

static uint8_t heap[4096];
static uint32_t offset = 0;

void* kalloc(uint32_t size) {
    if (offset + size >= sizeof(heap)) return 0;
    void* ptr = &heap[offset];
    offset += size;
    return ptr;
}