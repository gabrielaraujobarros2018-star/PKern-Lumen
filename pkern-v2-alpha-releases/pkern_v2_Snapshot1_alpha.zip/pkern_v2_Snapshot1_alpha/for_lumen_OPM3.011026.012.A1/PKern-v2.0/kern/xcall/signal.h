#ifndef KERNEL_IPC_SIGNAL_H
#define KERNEL_IPC_SIGNAL_H

void signal_raise(int sig);

#endif