#include <stdint.h>

int fs_probe(void) {
    return 0;
}