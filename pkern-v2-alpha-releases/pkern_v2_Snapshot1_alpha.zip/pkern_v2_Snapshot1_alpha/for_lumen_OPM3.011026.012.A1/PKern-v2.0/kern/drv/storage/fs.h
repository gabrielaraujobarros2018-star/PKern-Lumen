#ifndef KERNEL_DRIVERS_STORAGE_FS_H
#define KERNEL_DRIVERS_STORAGE_FS_H

int fs_probe(void);

#endif