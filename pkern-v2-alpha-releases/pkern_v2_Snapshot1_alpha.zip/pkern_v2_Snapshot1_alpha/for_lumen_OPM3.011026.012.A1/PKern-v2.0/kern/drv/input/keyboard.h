#ifndef KERNEL_DRIVERS_INPUT_KEYBOARD_H
#define KERNEL_DRIVERS_INPUT_KEYBOARD_H

#include <stdint.h>

uint8_t keyboard_read(void);

#endif