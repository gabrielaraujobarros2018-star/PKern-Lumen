#ifndef KERNEL_SCHED_TASK_H
#define KERNEL_SCHED_TASK_H

void task_init(void);

#endif