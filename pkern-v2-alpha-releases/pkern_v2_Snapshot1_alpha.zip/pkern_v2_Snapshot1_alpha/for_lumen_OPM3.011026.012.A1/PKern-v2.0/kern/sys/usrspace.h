#ifndef KERNEL_SYS_USERSPACE_H
#define KERNEL_SYS_USERSPACE_H

int userspace_enter(void);

#endif