#ifndef KERNEL_SYS_SYSCALL_H
#define KERNEL_SYS_SYSCALL_H

#include <stdint.h>

uint64_t sys_null(void);

#endif