#ifndef KERNEL_ARCH_COMMON_CPUID_H
#define KERNEL_ARCH_COMMON_CPUID_H

#include <stdint.h>

void cpu_cpuid(uint32_t code, uint32_t* a, uint32_t* d);

#endif