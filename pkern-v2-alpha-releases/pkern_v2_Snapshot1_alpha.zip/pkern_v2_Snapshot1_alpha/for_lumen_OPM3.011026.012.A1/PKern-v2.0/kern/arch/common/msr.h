#ifndef KERNEL_ARCH_COMMON_MSR_H
#define KERNEL_ARCH_COMMON_MSR_H

#include <stdint.h>

uint64_t cpu_read_msr(uint32_t msr);

#endif