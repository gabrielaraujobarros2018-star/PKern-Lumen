#include <stdint.h>

static int fs_corrupt = 0;

void fs_mark_corrupt(void) {
    fs_corrupt = 1;
}

void fs_auto_repair(void) {
    if (!fs_corrupt)
        return;

    /* Read-only mount */
    /* Metadata scan */
    /* Repair tables */

    fs_corrupt = 0;
}

int fs_is_safe(void) {
    return !fs_corrupt;
}

/*
 * Runs:
 * - On mount
 * - On corruption detection
 */