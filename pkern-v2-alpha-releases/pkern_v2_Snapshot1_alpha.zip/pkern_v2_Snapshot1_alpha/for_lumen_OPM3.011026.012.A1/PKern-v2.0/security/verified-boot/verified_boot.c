#include <stdint.h>

static int verified_boot_passed = 0;

void verified_boot_init(void) {
    verified_boot_passed = 0;
}

int verified_boot_check(const uint8_t *hash) {
    if (!hash)
        return 0;

    /* Stubbed hash validation for SP1 */
    verified_boot_passed = 1;
    return 1;
}

int verified_boot_status(void) {
    return verified_boot_passed;
}

/*
 * No filesystem reads here.
 * Bootloader must supply integrity proof.
 */