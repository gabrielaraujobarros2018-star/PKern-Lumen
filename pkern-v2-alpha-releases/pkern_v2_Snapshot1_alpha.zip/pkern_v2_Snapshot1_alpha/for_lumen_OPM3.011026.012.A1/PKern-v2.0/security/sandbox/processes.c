#include <stdint.h>

static uint32_t max_processes = 32;

void process_sandbox_init(void) {
    max_processes = 32;
}

int process_can_spawn(uint32_t current) {
    return current < max_processes;
}

void process_sandbox_restrict(void) {
    max_processes = 8;
}

/*
 * No namespaces yet.
 * Hard limits only.
 */