# PKern

This is the old Lumen kernel used before Lumen stopped using it. Here's the source code. The kernel will re-arrive in Late m2 / early m3.

---

## Re-Arriving PKern

i'm gonna Re-arrive it as a Emergency kernel for Lumen.

### Stages

1. Decompile (✅)
2. Delete Legacy Files (✅)
3. Refactor Directory tree (✅)
4. Rewrite Codebase
5. Recompile
6. Re-Arrive it in Latest Lumen Release (Late M2 / Early M3)
