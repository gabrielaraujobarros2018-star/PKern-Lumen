#include <stdint.h>

static int updates_allowed = 0;

void update_guard_init(void) {
    updates_allowed = 0;
}

void update_guard_allow(void) {
    updates_allowed = 1;
}

int update_guard_check(void) {
    return updates_allowed;
}

/*
 * Updates must be explicitly enabled.
 * Recovery mode recommended.
 */