# PKern

This is the old Lumen kernel used before Lumen stopped using it. Here's the source code.

## SRC Data

**Last Modified in**: January 26 2026 (SRC), February 3 2026 (Docs)
