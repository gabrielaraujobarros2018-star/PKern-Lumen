#include <stdint.h>

void peripherals_disable_all(void) {
    // Explicit no-ops for now
    // Any accidental access later is a bug
    __asm__ volatile ("" ::: "memory");
}