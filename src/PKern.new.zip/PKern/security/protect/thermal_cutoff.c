/* NeoKern/security/protect/thermal_cutoff.c */
#include <stdint.h>

static int max_temp_c = 95;
static int current_temp = 0;

void thermal_update(int temp_c) {
    current_temp = temp_c;
}

void thermal_set_limit(int temp_c) {
    max_temp_c = temp_c;
}

void thermal_check(void) {
    if (current_temp >= max_temp_c) {
        /* Emergency shutdown */
        for (;;) {
#if defined(__x86_64__)
            __asm__ volatile ("hlt");
#elif defined(__aarch64__)
            __asm__ volatile ("wfi");
#endif
        }
    }
}

/*
 * Hardware safety > uptime.
 * No throttling games.
 */