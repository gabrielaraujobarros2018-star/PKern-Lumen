#include <stdint.h>

static int artifacts_enabled = 0;

void screen_artifacts_enable(void) {
    artifacts_enabled = 1;
}

void screen_artifacts_render(void) {
    if (!artifacts_enabled)
        return;

    volatile uint32_t *fb = (uint32_t *)0x0; /* platform mapped */
    for (int i = 0; i < 256; i++) {
        fb[i] ^= 0x00FF00FF;
    }
}

void screen_artifacts_disable(void) {
    artifacts_enabled = 0;
}

/*
 * Purpose:
 * - User-visible failure signal
 * - Prevent silent data corruption
 */