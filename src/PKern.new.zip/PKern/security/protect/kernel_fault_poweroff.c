#include <stdint.h>

void kernel_fault_detected(uint32_t code) {
    (void)code;

    /* No panic loop */
    /* No recovery attempt */
    /* No logging after fault */

    for (;;) {
#if defined(__x86_64__)
        __asm__ volatile ("cli; hlt");
#elif defined(__aarch64__)
        __asm__ volatile ("msr daifset, #0xf; wfi");
#endif
    }
}

/*
 * Security posture:
 * - Faulted kernel must not continue
 * - Power off beats undefined execution
 */