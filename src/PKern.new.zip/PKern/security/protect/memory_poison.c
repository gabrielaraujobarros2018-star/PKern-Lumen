/* NeoKern/security/protect/memory_poison.c */
#include <stdint.h>

#define POISON_PATTERN 0xDEADBEEFDEADBEEFULL

static int poison_enabled = 1;

void memory_poison_enable(void) {
    poison_enabled = 1;
}

void memory_poison_disable(void) {
    poison_enabled = 0;
}

void memory_poison_region(void *addr, uint64_t size) {
    if (!poison_enabled || !addr || size == 0)
        return;

    uint64_t *p = (uint64_t *)addr;
    uint64_t count = size / sizeof(uint64_t);

    for (uint64_t i = 0; i < count; i++) {
        p[i] = POISON_PATTERN;
    }
}

int memory_poison_check(uint64_t value) {
    return value == POISON_PATTERN;
}

/*
 * Purpose:
 * - Detect UAF
 * - Detect stale pointers
 * - Fail fast instead of corrupting silently
 */