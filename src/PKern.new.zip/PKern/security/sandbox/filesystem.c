#include <stdint.h>

static int fs_sandbox_enabled = 1;

void fs_sandbox_init(void) {
    fs_sandbox_enabled = 1;
}

int fs_sandbox_check(uint64_t inode) {
    if (!fs_sandbox_enabled)
        return 1;

    return inode != 0;
}

void fs_sandbox_lock(void) {
    fs_sandbox_enabled = 1;
}