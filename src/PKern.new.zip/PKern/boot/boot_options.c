#include <stdint.h>

#define BOOT_OPTION_RECOVERY   (1 << 0)
#define BOOT_OPTION_SAFE_MODE  (1 << 1)
#define BOOT_OPTION_SETUP      (1 << 2)

static uint32_t boot_flags;

void boot_options_init(uint32_t flags) {
    boot_flags = flags;
}

int boot_option_enabled(uint32_t option) {
    return (boot_flags & option) != 0;
}

void boot_options_lockdown(void) {
    /* Once kernel init passes, options cannot change */
    boot_flags &= ~(BOOT_OPTION_SETUP);
}

uint32_t boot_options_snapshot(void) {
    return boot_flags;
}

/*
 * Security notes:
 * - No string parsing
 * - No dynamic config
 * - Flags come only from bootloader
 * - Setup Wizard is never implicit
 */