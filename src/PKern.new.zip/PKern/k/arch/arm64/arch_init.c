#include <stdint.h>
#include "../../include/kernel.h"

void arch_arm64_init(void) {
    kernel_log("ARCH INIT ARM64");

    uint64_t sctlr;
    __asm__ volatile("mrs %0, sctlr_el1" : "=r"(sctlr));

    if (!(sctlr & 1)) {
        kernel_panic("MMU DISABLED");
    }
}