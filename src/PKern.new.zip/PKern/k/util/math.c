#include <stdint.h>

uint32_t math_abs(int32_t v) {
    return (v < 0) ? -v : v;
}

uint32_t math_min(uint32_t a, uint32_t b) {
    return (a < b) ? a : b;
}