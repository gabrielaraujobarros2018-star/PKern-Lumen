#ifndef KERNEL_DRIVERS_POWER_SHUTDOWN_H
#define KERNEL_DRIVERS_POWER_SHUTDOWN_H

void system_shutdown(void);

#endif