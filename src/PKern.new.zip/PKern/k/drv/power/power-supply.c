#include <stdint.h>

int power_online(void) {
    return 1;
}