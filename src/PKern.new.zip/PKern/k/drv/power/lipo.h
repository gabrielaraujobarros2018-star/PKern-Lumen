#ifndef KERNEL_DRIVERS_POWER_LIPO_H
#define KERNEL_DRIVERS_POWER_LIPO_H

int lipo_detected(void);

#endif