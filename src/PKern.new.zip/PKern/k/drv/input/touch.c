#include <stdint.h>

int touch_supported(void) {
    return 0;
}