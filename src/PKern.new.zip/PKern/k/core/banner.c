#include <stdint.h>

/* These are IMPLEMENTED in debug.c */
extern void debug_banner(void);
extern void debug_checkpoint(const char *msg);

void banner_show(void)
{
    debug_banner();
    debug_checkpoint("banner_show");
}