#include <panic.h>
#include <stdint.h>

__attribute__((noreturn))
void panic(uint64_t code)
{
    (void)code;

    for (;;)
    {
        __asm__ volatile ("hlt");
    }
}