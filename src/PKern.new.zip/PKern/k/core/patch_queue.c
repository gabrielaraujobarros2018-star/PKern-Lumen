#include <stdint.h>

#define MAX_PATCHES 64

static const char *patches[MAX_PATCHES];
static uint32_t patch_count = 0;

int kernel_patch_register(const char *name) {
    if (!name) return -1;
    if (patch_count >= MAX_PATCHES) return -1;

    patches[patch_count++] = name;
    return 0;
}

uint32_t kernel_patch_count(void) {
    return patch_count;
}

const char *kernel_patch_get(uint32_t idx) {
    if (idx >= patch_count) return 0;
    return patches[idx];
}