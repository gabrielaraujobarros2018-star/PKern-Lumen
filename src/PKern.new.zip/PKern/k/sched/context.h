#ifndef KERNEL_SCHED_CONTEXT_H
#define KERNEL_SCHED_CONTEXT_H

#include <stdint.h>

void context_switch(uint64_t* new_stack);

#endif