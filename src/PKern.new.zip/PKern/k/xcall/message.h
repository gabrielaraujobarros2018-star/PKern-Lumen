#ifndef KERNEL_IPC_MESSAGE_H
#define KERNEL_IPC_MESSAGE_H

#include <stdint.h>

void ipc_send(uint32_t from, uint32_t value);

#endif