#include <stdint.h>

#define MAX_THREADS 256

struct kthread {
    uint32_t tid;
    void (*entry)(void *);
    void *arg;
};

static struct kthread threads[MAX_THREADS];
static uint32_t next_tid = 1;

uint32_t kthread_create(void (*fn)(void *), void *arg) {
    if (!fn || next_tid >= MAX_THREADS) return 0;

    threads[next_tid].tid = next_tid;
    threads[next_tid].entry = fn;
    threads[next_tid].arg = arg;

    return next_tid++;
}