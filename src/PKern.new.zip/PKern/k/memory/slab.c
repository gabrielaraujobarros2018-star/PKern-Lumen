#include <stdint.h>

void slab_init(void) {
    /* slab allocator init */
}