#pragma once
#include <stdint.h>

#define PALISADE_KERNEL_MAJOR 0
#define PALISADE_KERNEL_MINOR 1
#define PALISADE_KERNEL_PATCH 0

#define PALISADE_BUILD_ID "b01172026"

struct kernel_version {
    uint32_t major;
    uint32_t minor;
    uint32_t patch;
    const char *build;
};

void kernel_panic(const char *);
void kernel_log(const char *);
const struct kernel_version *kernel_get_version(void);