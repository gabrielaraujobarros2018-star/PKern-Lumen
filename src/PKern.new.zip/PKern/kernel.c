#include <stdint.h>

extern void serial_init(void);
extern void serial_write(const char *s);
extern void debug_banner(void);
extern void debug_checkpoint(const char *stage);
extern void debug_halt(void);

extern void runtime_init(void);
extern void *heap_alloc(uint64_t size);
extern uint64_t heap_used(void);

extern void timer_init(void);
extern int timer_is_ready(void);

extern int mmu_validate_state(void);
extern int interrupts_are_disabled(void);
extern void interrupts_enforce_off(void);
extern void panic(uint64_t code);

void kernel_main(void) {
    interrupts_enforce_off();
    serial_init();
    debug_banner();

    debug_checkpoint("kernel entry");

    if (!interrupts_are_disabled()) {
        panic(20);
    }

    if (mmu_validate_state() != 0) {
        panic(21);
    }

    runtime_init();
    debug_checkpoint("runtime initialized");

    void *test = heap_alloc(64);
    if (test == 0) {
        panic(22);
    }
    debug_checkpoint("heap online");

    timer_init();
    if (!timer_is_ready()) {
        panic(23);
    }
    debug_checkpoint("timer stub ready");

    serial_write("PalisadeOS runtime stable\n");
    debug_checkpoint("runtime OK");

    debug_halt();
}