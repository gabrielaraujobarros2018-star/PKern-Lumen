#include <stdint.h>

static int allow_suspend = 0;
static int allow_reboot = 1;

void power_policy_init(void) {
    allow_suspend = 0;
    allow_reboot = 1;
}

int power_can_suspend(void) {
    return allow_suspend;
}

int power_can_reboot(void) {
    return allow_reboot;
}

void power_lockdown(void) {
    allow_suspend = 0;
}

/*
 * Security rationale:
 * - Prevent suspend-based state attacks
 * - Reboot allowed only through kernel
 */