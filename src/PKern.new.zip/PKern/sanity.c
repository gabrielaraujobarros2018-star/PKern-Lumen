#include <stdint.h>

int sanity_ptr_valid(const void *p) {
    if (p == 0) {
        return 0;
    }

    if ((uintptr_t)p < 0x1000) {
        return 0;
    }

    return 1;
}

int sanity_range_valid(const void *start, const void *end) {
    if (!sanity_ptr_valid(start)) {
        return 0;
    }
    if (!sanity_ptr_valid(end)) {
        return 0;
    }
    if (start >= end) {
        return 0;
    }
    return 1;
}