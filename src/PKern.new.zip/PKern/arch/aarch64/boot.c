#include <stdint.h>
#include "kernel.h"

void arm_early_boot(void) {
    kernel_log("NeoKern AArch64 early boot");

    arm_cpu_init();
    arm_memory_init();

    kernel_main();

    for (;;) {
        asm volatile ("wfe");
    }
}

void arm_cpu_init(void) {
    kernel_log("ARM CPU init");
}

void arm_memory_init(void) {
    kernel_log("ARM memory init");
}