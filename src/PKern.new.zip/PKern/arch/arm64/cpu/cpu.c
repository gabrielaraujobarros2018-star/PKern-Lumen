#include <kernel.h>
#include <arch.h>
#include <regs.h>

void arch_init(void)
{
    unsigned long el = read_current_el();

    serial_write("CPU EL=");
    if (el == 1) serial_write("1\n");
    else if (el == 2) serial_write("2\n");
    else panic(0xBAD_EL);
}