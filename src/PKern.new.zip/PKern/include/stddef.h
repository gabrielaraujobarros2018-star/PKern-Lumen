#pragma once

/*
 * Freestanding stddef replacement
 */

#define NULL ((void*)0)

/* Size and pointer difference types */
typedef unsigned long size_t;
typedef signed long   ptrdiff_t;