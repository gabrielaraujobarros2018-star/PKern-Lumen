#pragma once

#include "types.h"

/*
 * AArch64 architecture interface
 * No x86 symbols allowed here
 */

void arm_early_boot(void);

void arm_cpu_init(void);
void arm_memory_init(void);

/* System register helpers */
static inline u64 read_current_el(void) {
    u64 el;
    asm volatile ("mrs %0, CurrentEL" : "=r"(el));
    return el >> 2;
}

static inline void arm_wait(void) {
    asm volatile ("wfe");
}

/* Disable IRQs */
static inline void arm_disable_irq(void) {
    asm volatile ("msr DAIFSet, #2");
}