#pragma once
#include <stdint.h>

#define PANIC_KERNEL_RETURN 0xDEAD0001

__attribute__((noreturn))
void panic(uint64_t code);