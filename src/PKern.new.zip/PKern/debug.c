#include <stdint.h>

extern void serial_write(const char *s);

void debug_banner(void) {
    serial_write("\n");
    serial_write("====================================\n");
    serial_write("   PalisadeOS b01182026 BOOT START   \n");
    serial_write("====================================\n");
}

void debug_checkpoint(const char *stage) {
    serial_write("[OK] ");
    serial_write(stage);
    serial_write("\n");
}

__attribute__((noreturn))
void debug_halt(void) {
    serial_write("[HALT] System stopped\n");
    while (1) {
        __asm__ volatile ("cli; hlt");
    }
}