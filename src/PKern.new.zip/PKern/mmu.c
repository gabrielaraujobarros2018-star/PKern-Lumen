#include <stdint.h>

static inline uint64_t read_cr0(void) {
    uint64_t val;
    __asm__ volatile ("mov %%cr0, %0" : "=r"(val));
    return val;
}

static inline uint64_t read_cr3(void) {
    uint64_t val;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(val));
    return val;
}

int mmu_validate_state(void) {
    uint64_t cr0 = read_cr0();
    uint64_t cr3 = read_cr3();

    if (!(cr0 & (1ULL << 31))) {
        return -1;  // Paging OFF → invalid for now
    }

    if (cr3 == 0) {
        return -2;  // No page tables
    }

    return 0;
}