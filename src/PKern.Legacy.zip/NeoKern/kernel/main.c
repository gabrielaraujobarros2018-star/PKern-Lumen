#include <stdint.h>

extern void kernel_log(const char*);

void kernel_main(void) {
    kernel_log("NeoKern: kernel_main entered");
    while (1) {
        __asm__ volatile ("hlt");
    }
}