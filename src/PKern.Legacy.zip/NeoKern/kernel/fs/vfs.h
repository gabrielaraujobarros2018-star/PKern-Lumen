#ifndef KERNEL_FS_VFS_H
#define KERNEL_FS_VFS_H

int vfs_mount(const char* fs);

#endif