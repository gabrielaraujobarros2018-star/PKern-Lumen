#include <stdint.h>
#include "../../include/kernel.h"

void arch_x86_64_init(void) {
    kernel_log("ARCH INIT x86_64");

    __asm__ volatile("cli");

    uint64_t cr0;
    __asm__ volatile("mov %%cr0, %0" : "=r"(cr0));

    if (!(cr0 & 1)) {
        kernel_panic("CR0 PROTECTION DISABLED");
    }

    __asm__ volatile("sti");
}