#ifndef KERNEL_ARCH_COMMON_SMP_H
#define KERNEL_ARCH_COMMON_SMP_H

#include <stdint.h>

uint8_t smp_cpu_count(void);

#endif