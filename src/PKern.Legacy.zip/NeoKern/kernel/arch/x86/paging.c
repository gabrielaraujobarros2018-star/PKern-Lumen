#include <stdint.h>

void paging_init(void) {
    __asm__ volatile ("nop");
}