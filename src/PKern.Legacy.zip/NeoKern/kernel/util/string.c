#include <stdint.h>

uint32_t strlen(const char* s) {
    uint32_t len = 0;
    while (s && *s++) len++;
    return len;
}

int strcmp(const char* a, const char* b) {
    while (*a && (*a == *b)) {
        a++; b++;
    }
    return *(const unsigned char*)a - *(const unsigned char*)b;
}