#include <stdint.h>

typedef struct {
    uint64_t rip;
    uint64_t rsp;
    uint8_t  state;
} task_t;

static task_t task_table[8];

void task_init(void) {
    for (int i = 0; i < 8; i++) {
        task_table[i].state = 0;
    }
}