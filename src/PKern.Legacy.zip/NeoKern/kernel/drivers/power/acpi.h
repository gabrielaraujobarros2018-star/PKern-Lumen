#ifndef KERNEL_DRIVERS_POWER_ACPI_H
#define KERNEL_DRIVERS_POWER_ACPI_H

int acpi_available(void);

#endif