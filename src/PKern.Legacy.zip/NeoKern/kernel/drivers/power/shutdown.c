#include <stdint.h>

void system_shutdown(void) {
    __asm__ volatile (
        "mov $0x604, %dx\n"
        "mov $0x2000, %ax\n"
        "out %ax, %dx\n"
    );
    for (;;);
}