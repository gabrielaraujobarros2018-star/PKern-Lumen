#include <stdint.h>

int acpi_available(void) {
    return 0;
}