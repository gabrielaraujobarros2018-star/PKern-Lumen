#include <stdint.h>

int hdd_spinup(void) {
    return 0;
}