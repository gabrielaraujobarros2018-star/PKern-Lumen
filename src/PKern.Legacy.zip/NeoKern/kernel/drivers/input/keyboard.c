#include <stdint.h>

static uint8_t last_key;

uint8_t keyboard_read(void) {
    return last_key;
}