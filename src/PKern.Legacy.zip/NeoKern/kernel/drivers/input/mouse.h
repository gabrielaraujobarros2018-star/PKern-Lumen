#ifndef KERNEL_DRIVERS_INPUT_MOUSE_H
#define KERNEL_DRIVERS_INPUT_MOUSE_H

void mouse_init(void);

#endif