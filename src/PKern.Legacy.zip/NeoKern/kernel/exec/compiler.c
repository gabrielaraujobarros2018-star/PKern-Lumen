#include <stdint.h>

static int jit_enabled = 0;

void kernel_compiler_enable(void) {
    jit_enabled = 1;
}

int kernel_compiler_active(void) {
    return jit_enabled;
}