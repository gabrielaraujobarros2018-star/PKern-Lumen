#include <stdint.h>

static uint32_t runnable = 0;

void kernel_schedule_add(void) {
    runnable++;
}

uint32_t kernel_runnable_count(void) {
    return runnable;
}

void kernel_schedule_tick(void) {
    if (runnable == 0) return;
}