#include "../include/kernel.h"

static const char build_stamp[] = PALISADE_BUILD_ID;

const char *kernel_build_id(void) {
    return build_stamp;
}

int kernel_build_is_expected(void) {
    const char *id = kernel_build_id();
    if (!id) return 0;
    return id[0] == 'b';
}