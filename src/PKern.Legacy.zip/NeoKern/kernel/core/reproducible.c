#include <stdint.h>

static uint64_t fixed_seed = 0x01172026;

void kernel_reproducible_seed(uint64_t *out) {
    if (!out) return;
    *out = fixed_seed;
}

uint64_t kernel_build_seed(void) {
    return fixed_seed;
}

void kernel_reproducible_assert(uint64_t in) {
    if (in != fixed_seed) {
        for (;;) {}
    }
}