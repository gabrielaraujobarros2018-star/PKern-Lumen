#include "../include/kernel.h"

static struct kernel_version version = {
    .major = PALISADE_KERNEL_MAJOR,
    .minor = PALISADE_KERNEL_MINOR,
    .patch = PALISADE_KERNEL_PATCH,
    .build = PALISADE_BUILD_ID
};

const struct kernel_version *kernel_get_version(void) {
    return &version;
}

int kernel_version_match(uint32_t maj, uint32_t min) {
    if (version.major != maj) return 0;
    if (version.minor != min) return 0;
    return 1;
}