#include <stdint.h>

void paging_enable(void) {
    __asm__ volatile ("mov %cr0, %eax");
}