#ifndef NEOKERN_MMU_H
#define NEOKERN_MMU_H

#include "types.h"

int mmu_validate_state(void);
void mmu_enable(void);
void mmu_disable(void);

#endif