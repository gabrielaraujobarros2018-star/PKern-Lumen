#ifndef NEOKERN_PANIC_H
#define NEOKERN_PANIC_H

#include "types.h"

__attribute__((noreturn))
void panic(u64 code);

/* Enforced guard: missing headers must fail loudly */
#define REQUIRE_HEADER() \
    do { \
        volatile int __hdr = 1; \
        if (!__hdr) panic(0xDEAD0001); \
    } while (0)

#endif