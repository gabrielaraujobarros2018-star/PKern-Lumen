#ifndef NEOKERN_INTERRUPTS_H
#define NEOKERN_INTERRUPTS_H

#include "types.h"

void interrupts_enforce_off(void);
void interrupts_enable(void);
int  interrupts_are_disabled(void);

#endif