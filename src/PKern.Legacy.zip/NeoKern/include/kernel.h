#ifndef NEOKERN_KERNEL_H
#define NEOKERN_KERNEL_H

#include "types.h"

/* Entry */
void kernel_main(void);

/* Panic */
__attribute__((noreturn))
void panic(u64 code);

/* Debug */
void debug_banner(void);
void debug_checkpoint(const char *stage);
__attribute__((noreturn))
void debug_halt(void);

/* Interrupts */
void interrupts_enforce_off(void);
int  interrupts_are_disabled(void);

/* MMU */
int mmu_validate_state(void);

/* Runtime */
void runtime_init(void);

/* Heap */
void *heap_alloc(u64 size);
u64   heap_used(void);

/* Timer */
void timer_init(void);
int  timer_is_ready(void);
u64  timer_ticks(void);

/* Serial */
void serial_init(void);
void serial_write(const char *s);

#endif