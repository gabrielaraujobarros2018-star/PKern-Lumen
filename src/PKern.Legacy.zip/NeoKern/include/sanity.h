#ifndef NEOKERN_SANITY_H
#define NEOKERN_SANITY_H

#include "types.h"

int sanity_ptr_valid(const void *p);
int sanity_range_valid(const void *start, const void *end);

#endif