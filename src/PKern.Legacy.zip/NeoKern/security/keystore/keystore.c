#include <stdint.h>

#define MAX_KEYS 8

static uint64_t keys[MAX_KEYS];
static uint32_t key_count;

void keystore_init(void) {
    key_count = 0;
}

int keystore_add(uint64_t key) {
    if (key_count >= MAX_KEYS)
        return -1;

    keys[key_count++] = key;
    return 0;
}

uint64_t keystore_get(uint32_t index) {
    if (index >= key_count)
        return 0;

    return keys[index];
}

/*
 * No persistence.
 * Keys die with power loss.
 */