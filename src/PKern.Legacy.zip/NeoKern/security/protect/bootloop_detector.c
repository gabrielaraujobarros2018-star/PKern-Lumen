/* NeoKern/security/protect/bootloop_detector.c */
#include <stdint.h>

static uint32_t boot_failures = 0;
static uint32_t boot_fail_limit = 3;

void bootloop_record_failure(void) {
    boot_failures++;
}

int bootloop_should_recover(void) {
    return boot_failures >= boot_fail_limit;
}

void bootloop_reset(void) {
    boot_failures = 0;
}

void bootloop_set_limit(uint32_t limit) {
    boot_fail_limit = limit;
}

/*
 * Prevents infinite reboot damage.
 * Forces recovery path.
 */