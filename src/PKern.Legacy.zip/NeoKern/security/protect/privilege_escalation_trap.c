/* NeoKern/security/protect/privilege_escalation_trap.c */
#include <stdint.h>

void privilege_violation_detected(uint32_t from, uint32_t to) {
    (void)from;
    (void)to;

    /* Any unexpected privilege transition is fatal */
    for (;;) {
#if defined(__x86_64__)
        __asm__ volatile ("cli; hlt");
#elif defined(__aarch64__)
        __asm__ volatile ("msr daifset, #0xf; wfi");
#endif
    }
}

/*
 * No logging.
 * No recovery.
 * Security over availability.
 */