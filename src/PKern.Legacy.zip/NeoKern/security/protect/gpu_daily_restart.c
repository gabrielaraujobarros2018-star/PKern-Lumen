#include <stdint.h>

static uint64_t last_restart_ticks = 0;

void gpu_restart_check(uint64_t now) {
    if ((now - last_restart_ticks) > (24ULL * 60 * 60)) {
        last_restart_ticks = now;
        /* GPU + compositor hard reset */
    }
}

void gpu_force_restart(void) {
    last_restart_ticks = 0;
}

/*
 * Rationale:
 * - Prevent long-lived driver leaks
 * - Flush corrupted GPU state
 */