#include <stdint.h>

static int battery_percent = 100;

void battery_update_level(int percent) {
    battery_percent = percent;
}

void battery_check_shutdown(void) {
    if (battery_percent <= 0) {
        /* No save, no sync, no mercy */
        for (;;) {
#if defined(__aarch64__)
            __asm__ volatile ("wfi");
#elif defined(__x86_64__)
            __asm__ volatile ("hlt");
#endif
        }
    }
}

/*
 * Rationale:
 * - Prevent brownout corruption
 * - Battery lies less than software
 * - Power loss is safer than flash damage
 */